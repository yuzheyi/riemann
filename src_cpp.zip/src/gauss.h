#include "Fvm.h"

void gaussSolver(double* a, double* b,Cell* cells,int cols,int raws); //a 为方阵 ，b 为列向量

 


 